package com.ecomsmart.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComSmartBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
